# Cards Basics

TODO

Next, learn how to use the [Card Designer](designer)
