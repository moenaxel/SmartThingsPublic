# Using expressions in component configuration

TODO
