# Welcome to HABot Help

This is the help site for HABot.

These pages are meant to be accessed from the app itself, under the Help section.
