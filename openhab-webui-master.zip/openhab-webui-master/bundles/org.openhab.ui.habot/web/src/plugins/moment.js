import VueMoment from 'vue-moment'

export default ({ app, router, Vue }) => {
  Vue.use(VueMoment)
}
