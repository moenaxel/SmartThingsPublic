export default {
  ready: false,
  items: [],
  map: {},
  connectionBroken: false
}
