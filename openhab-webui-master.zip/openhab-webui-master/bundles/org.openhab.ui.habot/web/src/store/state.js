export default {
  ready: false,
  lang: 'en',
  usingStoredCredentials: false
}
