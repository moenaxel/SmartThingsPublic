export default {
  cards: []
}
